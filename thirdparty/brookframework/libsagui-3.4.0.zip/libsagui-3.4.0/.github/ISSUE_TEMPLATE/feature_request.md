---
name: Feature request
about: Suggest a feature for this project
labels: enhancement

---

A clear and concise description of what should be improved in Sagui library.

Any links, projects or drafts can be referenced if they could help to explain the feature.
