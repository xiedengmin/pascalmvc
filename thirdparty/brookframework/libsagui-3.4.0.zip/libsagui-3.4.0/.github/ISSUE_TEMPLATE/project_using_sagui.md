---
name: Project using Sagui
about: Free or commercial project using Sagui library
labels: documentation

---

A description/link and the license of the project, e.g.:

[Brook framework](https://github.com/risoflora/brookframework) - Pascal framework which helps to develop web applications. [[LGPL v2.1](https://github.com/risoflora/brookframework/blob/master/LICENSE)]
